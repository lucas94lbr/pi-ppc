<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
			  <!-- Default panel contents -->
				<div class="panel-heading">PPC's Cadastrados 
			  		<a href="/planos/create" class="btn btn-sm btn-success pull-right">Novo PPC</a>
			  	</div>
			  	<div class="panel-body">
			    	<table class="table">
			          	<thead class="thead-dark">
			            	<tr>
			              		<th scope="col">#</th>
					              <th scope="col">Curso</th>
					              <th scope="col">Turno</th>
					              <th scope="col">Modalidade</th>
					              <th scope="col">Vagas</th>
					              <th scope="col">Ações</th>
					            </tr>
			          	</thead>
	          			<tbody>
			            	
	          			</tbody>
        			</table>
			  	</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>