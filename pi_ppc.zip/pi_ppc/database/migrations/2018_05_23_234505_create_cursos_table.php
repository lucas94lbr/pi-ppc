<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCursosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cursos', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nome-curso');
            $table->string('modalidade');
            $table->string('deno_curso');
            $table->string('habilitacao');
            $table->string('turno');
            $table->string('local');
            $table->integer('vagas');
            $table->integer('ch');
            $table->string('regime');
            $table->string('periodos');

            $table->integer('coordenador_id')->unsigned()->index();
            $table->foreign('coordenador_id')->references('id')
                                             ->on('coordenadors')
                                             ->onDelete('cascade');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cursos');
    }
}
