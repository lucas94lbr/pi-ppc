<?php

return [

	// Flash Messages
	'createSuccess'     => 'Usuário criado com sucesso! ',
	'updateSuccess'     => 'Usuário atualizado com success! ',
	'deleteSuccess'     => 'Usuário excluído com success! ',
	'deleteSelfError'   => 'Você não pode se excluir! ',

	// Show User Tab
	'viewProfile'		=> "Ver Perfil",
	'editUser'			=> 'Editar Usuário',
	'deleteUser'		=> 'Deletar Usuário',
	'usersBackBtn'      => 'Voltar para os Usuários',
	'usersPanelTitle'   => 'Informações do Usuário',
	'labelUserName'     => 'Nome de Usuário:',
	'labelEmail'        => 'E-mail:',
	'labelFirstName'    => 'Primeiro Nome:',
	'labelLastName'     => 'Último Nome:',
	'labelRole'         => 'Função:',
	'labelStatus'       => 'Status:',
	'labelAccessLevel'  => 'Acesso',
	'labelPermissions'  => 'Permissões:',
	'labelCreatedAt'    => 'Criado em:',
	'labelUpdatedAt'    => 'Atualizado em:',
	'labelIpEmail'      => 'Endereço de e-mail IP:',
	'labelIpEmail'      => 'Endereço de e-mail IP:',
	'labelIpConfirm'    => 'Confirmação de IP:',
	'labelIpSocial'     => 'Socialite Signup IP:',
	'labelIpAdmin'      => 'Admin Signup IP:',
	'labelIpUpdate'     => 'Última Atualização de IP:',
	'labelDeletedAt'	=> 'Deleted on',
	'labelIpDeleted'	=> 'Deleted IP:',
	'usersDeletedPanelTitle' => 'Deleted User Information',
	'usersBackDelBtn'	=> 'Back to Deleted Users',

	'successRestore' 	=> 'Usuário successfully restored.',
	'successDestroy' 	=> 'Usuário record successfully destroyed.',
	'errorUserNotFound' => 'Usuário not found.',

	'labelUserLevel'	=> 'Level',
	'labelUserLevels'	=> 'Levels',

];
