<?php

return [

	// Permissions
	'permissionView'      => 'Ver',
	'permissionCreate'    => 'Criar',
	'permissionEdit'      => 'Editar',
	'permissionDelete'    => 'Excluir',

];
