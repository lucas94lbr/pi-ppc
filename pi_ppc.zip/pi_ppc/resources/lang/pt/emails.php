<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Emails Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for various emails that
    | we need to display to the user. You are free to modify these
    | language lines according to your application's requirements.
    |
    */

    /**
     * Activate new user account email.
     *
     */

    'activationSubject'  => 'Ativação necessária',
    'activationGreeting' => 'Bem-vindo!',
    'activationMessage'  => 'Você precisa ativar seu e-mail antes de começar a usar todos os nossos serviços.',
    'activationButton'   => 'Ativar Conta',
    'activationThanks'   => 'Obrigado por usar nossa aplicação!',

    /**
     * Goobye email.
     *
     */
    'goodbyeSubject'    => 'Desculpe ver você ir ...',
    'goodbyeGreeting'   => 'Olá :username,',
    'goodbyeMessage'    => 'Lamentamos vê-lo ir. Queríamos deixar você saber que sua conta foi excluída. Agradeço o tempo que compartilhamos. Você tem ' . config('settings.restoreUserCutoff') . 'Dias para restaurar sua conta',
    'goodbyeButton'     => 'Restauração de Conta',
    'goodbyeThanks'     => 'Esperamos vê-lo novamente!',

];
