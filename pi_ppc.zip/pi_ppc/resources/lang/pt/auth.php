<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Essas credenciais não correspondem aos nossos registros.',
    'throttle' => 'Muitas tentativas de login. Tente novamente em: segundos segundos.',

    // Activation items
    'sentEmail'         => 'Enviamos um e-mail para: email.',
    'clickInEmail'      => 'Por favor, clique no link para ativar sua conta.',
    'anEmailWasSent'    => 'Um e-mail foi enviado para  :email em :date.',
    'clickHereResend'   => 'Clique aqui para reenviar o e-mail.',
    'successActivated'  => 'Sucesso, sua conta foi ativada.',
    'unsuccessful'      => 'Sua conta não pôde ser ativada; Por favor, tente novamente.',
    'notCreated'        => 'Sua conta não pôde ser criada; Por favor, tente novamente.',
    'tooManyEmails'     => 'Muitos e-mails de ativação foram enviados para :email. <br /> Tente novamente em <span class="label label-danger"> :hours horas </ span>.',
    'regThanks'         => 'Obrigado por se cadastrar, ',
    'invalidToken'      => 'Token de ativação inválido. ',
    'activationSent'    => 'E-mail de ativação enviado. ',
    'alreadyActivated'  => 'Já foi ativado. ',

    // Labels
    'whoops'            => 'Ops! ',
    'someProblems'      => 'Houve alguns problemas com seus dados.',
    'email'             => 'Endereço de E-Mail',
    'password'          => 'Senha',
    'rememberMe'        => ' Lembrar-me',
    'login'             => 'Login',
    'forgot'            => 'Esqueceu sua senha?',
    'forgot_message'    => 'Problemas com a senha?',
    'name'              => 'Username',
    'first_name'        => 'Primeiro Nome',
    'last_name'         => 'Último Nome',
    'confirmPassword'   => 'Confirmar Senha',
    'register'          => 'Cadastrar',

    // Placeholders
    'ph_name'           => 'Username',
    'ph_email'          => 'Endereço de E-mail',
    'ph_firstname'      => 'Primeiro Nome',
    'ph_lastname'       => 'Último Nome',
    'ph_password'       => 'Senha',
    'ph_password_conf'  => 'Confirmar Senha',

    // User flash messages
    'sendResetLink'     => 'Send Password Reset Link',
    'resetPassword'     => 'Resetar senha',
    'loggedIn'          => 'You are logged in!',

    // email links
    'pleaseActivate'    => 'Por favor, ative sua conta.',
    'clickHereReset'    => 'Clique aqui para resetar sua senha: ',
    'clickHereActivate' => 'Clique aqui para ativar sua conta: ',

    // Validators
    'userNameTaken'     => 'Username indisponível',
    'userNameRequired'  => 'Username é necessário',
    'fNameRequired'     => 'Primeiro Nome é necessário',
    'lNameRequired'     => 'Último Nome é necessário',
    'emailRequired'     => 'E-mail é necessário',
    'emailInvalid'      => 'E-mail inválido',
    'passwordRequired'  => 'A senha é necessária',
    'PasswordMin'       => 'A senha precisa ter pelo menos 6 caracteres',
    'PasswordMax'       => 'O comprimento máximo da senha é de 20 caracteres',
    'captchaRequire'    => 'Captcha é requerido',
    'CaptchaWrong'      => 'Captcha errado, tente novamente.',
    'roleRequired'      => 'A Função Usuário é necessária.'

];
