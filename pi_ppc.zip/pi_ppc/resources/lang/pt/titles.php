<?php

return [

	'app'			=> 'Projeto Pedagógico de Curso',
	'app2'			=> 'IESB',
	'home'			=> 'Home',
	'login'			=> 'Login',
	'logout'		=> 'Sair do Sistema',
	'register'		=> 'Registrar Usuário',
	'resetPword'	=> 'Reiniciar Senha',
	'toggleNav'		=> 'Toggle Navigation',
	'profile'		=> 'Meu Perfil',
	'editProfile'	=> 'Editar Perfil',
	'createProfile'	=> 'Criar Perfil',

	'activation'	=> 'Registration Started  | Activation Required',
	'exceeded'		=> 'Erro de Ativação',

	'editProfile'	=> 'Editar Perfil',
	'createProfile'	=> 'Criar Perfil',
	'adminUserList'	=> 'Usuários Cadastrados',
	'adminEditUsers'=> 'Editar Usuários',
	'adminNewUser'	=> 'Criar Novo Usuário',

	'adminThemesList' => 'Temas',
	'adminThemesAdd'  => 'Adicionar Novo Tema',

	'adminLogs'		=> 'Arquivos de Log ',
	'adminPHP'		=> 'Informações PHP ',
	'adminRoutes'	=> 'Detalhes de Rotas',

];
