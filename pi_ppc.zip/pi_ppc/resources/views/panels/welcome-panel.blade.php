@php

    $levelAmount = 'level';

    if (Auth::User()->level() >= 2) {
        $levelAmount = 'levels';

    }

@endphp


<div class="panel panel-primary @role('admin', true) panel-info  @endrole">
    <div class="panel-heading">

        Olá, {{ Auth::user()->first_name }} {{ Auth::user()->last_name }} ! 

        @role('admin', true)
            <span class="pull-right label label-primary" style="margin-top:4px">
            Acesso de Administrador
            </span>
        @else
            <span class="pull-right label label-warning" style="margin-top:4px">
            Acesso de Usuário
            </span>
        @endrole

    </div>
    <div class="panel-body">
        <h2 class="lead">
            Você entrou!
        </h2>
            Seja bem-vindo ao PPC - IESB 2018.

            <h2 class="text-center">Escolha uma das opções acima para iniciar.</h2>

    </div>
</div>
