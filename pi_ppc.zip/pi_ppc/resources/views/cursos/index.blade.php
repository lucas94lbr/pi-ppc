@extends('layouts.app')

@section('content')
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
			  <!-- Default panel contents -->
				<div class="panel-heading">Cursos Cadastrados 
			  		<a href="/cursos/create" class="btn btn-sm btn-success pull-right">Novo Curso</a>
			  	</div>
			  	<div class="panel-body">
			    	<table class="table">
			          	<thead class="thead-dark">
			            	<tr>
			              		<th scope="col">#</th>
					              <th scope="col">Curso</th>
					              <th scope="col">Turno</th>
					              <th scope="col">Modalidade</th>
					              <th scope="col">Vagas</th>
					              <th scope="col">Ações</th>
					            </tr>
			          	</thead>
	          			<tbody>
			            	@foreach($cursos as $curso)
			            		<tr>
			              			<th scope="row">{{$curso->id}}</th>
						            <td><a href="/cursos/{{$curso->id}}">{{$curso->nome_curso}}</a></td>
						            <td>{{$curso->turno}}</td>
						            <td>{{$curso->modalidade}}</td>
						            <td>{{$curso->vagas}}</td>
						            {{-- <td>{{$curso->created_at->toFormattedDateString()}}</td> --}}
						            <td>
			              				<div class="btn-group" role="group" aria-label="Basic example">
			                  				<a href="{{ URL::to('cursos/' . $curso->id . '/edit') }}">
			                   					<button type="button" class="btn btn-xs btn-warning">Editar</button>
			                  				</a>
					                  		<form action="{{url('cursos', [$curso->id])}}" method="POST">
					     						<input type="hidden" name="_method" value="DELETE">
											   	<input type="hidden" name="_token" value="{{ csrf_token() }}">
											   	<input type="submit" class="btn btn-xs btn-danger" value="Apagar"/>
					   				  		</form>
			              				</div>
			 						</td>
			            		</tr>
			            	@endforeach
	          			</tbody>
        			</table>
			  	</div>
			</div>
		</div>
	</div>

@endsection