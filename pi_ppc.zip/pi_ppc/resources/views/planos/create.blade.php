@extends('layouts.app')

@section('template_title')
  Criar novo usuário
@endsection

@section('template_fastload_css')
@endsection

@section('content')

  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">

            Criar Novo Curso

            <a href="/cursos" class="btn btn-info btn-xs pull-right">
              <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
              Voltar para <span class="hidden-xs"></span><span class="hidden-xs"> Cursos</span>
            </a>

          </div>
          <div class="panel-body">
            {!! Form::open(array('route' => 'cursos.store', 'files' => true)) !!}
              <legend>1 - Projeto Pedagógico de Curso</legend>
              <div class="col-md-12">
                
                <div class="col-md-6">
                  {!! Form::label('modalidade', '1.2 - Modalidade') !!} 
                  {!! Form::select('modalidade', ['EAD' => 'EAD', 'Presencial' => 'Presencial' , 'Semi-Presencial' => 'Semi-Presencial'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione a Modalidade']) !!}
                </div>
                <div class="col-md-12">
                  <div class="col-md-6">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
                  <div class="col-md-6">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
              </div>
              <div class="col-md-12">
                  <div class="col-md-6">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
                  <div class="col-md-6">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
              </div>
              <div class="col-md-12">
                  <div class="col-md-6">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
                  <div class="col-md-6">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
                  <div class="col-md-6">
                      {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                     {!! Form::input('text', 'nome_curso', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']) !!}
                    
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {!! Form::input('text', 'nome_curso', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']) !!}

                  </div>
                   <div class="col-md-12">
                    {!! Form::label('nome_curso', '1.3 - Curso ') !!}                 
                    {{ Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3']) }}
                  </div>
               </div>
               <div class="col-md-12" style="margin-top:50px">   
                            {!! Form::submit('Salvar', ['class' => 'btn btn-primary']) !!}
                            {!! Form::reset('Limpar formulário', ['class' => 'btn btn-default']) !!}
                        </div>
            {!! Form::close() !!} 
          </div>
        </div>
      </div>
    </div>
@endsection

@section('footer_scripts')
@endsection
