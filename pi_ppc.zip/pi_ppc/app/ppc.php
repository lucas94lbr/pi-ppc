<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ppc extends Model
{
    //
}
