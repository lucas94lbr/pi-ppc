<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Curso;
use App\Models\Coordenador;

class CursosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cursos = Curso::all();

        return view('cursos.index', compact('cursos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $coordenadores = Coordenador::all();

        return view('cursos.create')->withCoordenadores($coordenadores);;  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {



        $curso = new Curso;
        
        $curso->nome_curso      = $request->nome_curso;
        $curso->tipo_curso      = $request->tipo_curso;
        $curso->modalidade      = $request->modalidade;
        $curso->habilitacao     = $request->habilitacao;
        $curso->turno           = $request->turno;
        $curso->local           = $request->local;
        $curso->vagas           = $request->vagas;
        $curso->ch              = $request->carga_horaria;
        $curso->regime          = $request->regime;
        $curso->periodos        = $request->periodos;
        $curso->coordenador_id  = $request->coordenador_id;
        $curso->save();

       return redirect('cursos')->with('success', trans('Curso Criado com Sucesso!'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
        $curso = Curso::findOrFail($id);
        $curso->delete();

        return redirect('cursos')->with('success', trans('Curso excluído com sucesso!'));
    }
}
