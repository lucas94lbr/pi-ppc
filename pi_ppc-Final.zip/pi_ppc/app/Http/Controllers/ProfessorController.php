<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Professor;


class ProfessorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $professores = Professor::all();
        
        return view('professores.index', compact('professores'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $professores = Professor::all();

        return view('professores.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $professor = new Professor;
        
        $professor->nome        = $request->nome;
        $professor->titulacao   = $request->titulacao;
        $professor->tcc         = $request->tcc;
        $professor->area_formacao   = $request->area_formacao;
        $professor->lattes   = $request->lattes;
        $professor->data   = $request->data;
        
        $professor->save();

       return redirect('professores')->with('success', trans('Professor adicionado com Sucesso!'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     
        $professor = Curso::findOrFail($id);
        $professor->delete();

        return redirect('professor')->with('success', trans('Professor excluído com sucesso!'));
    

    }
}
