<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Coordenador extends Model
{
    //

	public function cursos()
    {
        
        return $this->hasMany('App\Models\Curso');
    }
}
