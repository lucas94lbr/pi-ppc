<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Curso extends Model
{
    //
    public function coordenador()
    {
    	return $this->belongsTo(Coordenador::class);
    }
}
