<?php

    $levelAmount = 'level';

    if (Auth::User()->level() >= 2) {
        $levelAmount = 'levels';

    }

?>


<div class="panel panel-primary <?php if (Auth::check() && Auth::user()->hasRole('admin', true)): ?> panel-info  <?php endif; ?>">
    <div class="panel-heading">

        Olá, <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?> ! 

        <?php if (Auth::check() && Auth::user()->hasRole('admin', true)): ?>
            <span class="pull-right label label-primary" style="margin-top:4px">
            Acesso de Administrador
            </span>
        <?php else: ?>
            <span class="pull-right label label-warning" style="margin-top:4px">
            Acesso de Usuário
            </span>
        <?php endif; ?>

    </div>
    <div class="panel-body">
        <h2 class="lead">
            Você entrou!
        </h2>
            Seja bem-vindo ao PPC - IESB 2018.

            <h2 class="text-center">Escolha uma das opções acima para iniciar.</h2>

    </div>
</div>
