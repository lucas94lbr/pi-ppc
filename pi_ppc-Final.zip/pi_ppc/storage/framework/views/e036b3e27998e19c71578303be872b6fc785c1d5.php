<?php $__env->startSection('template_title'); ?>
  Criar novo Planos de Ensino
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_fastload_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">

            Criar Novo Curso

            <a href="/cursos" class="btn btn-info btn-xs pull-right">
              <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
              Voltar para <span class="hidden-xs"></span><span class="hidden-xs"> Cursos</span>
            </a>

          </div>
          <div class="panel-body">
            <?php echo Form::open(array('route' => 'cursos.store', 'files' => true)); ?>

              <legend>1 - Projeto Pedagógico de Curso</legend>
              <div class="col-md-12">
                
                <div class="col-md-6">
                  <?php echo Form::label('modalidade', '1.1 - Curso'); ?> 
                  <?php echo Form::select('modalidade', ['EAD' => 'EAD', 'Presencial' => 'Presencial' , 'Semi-Presencial' => 'Semi-Presencial'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione a Modalidade']); ?>

                </div>
                <div class="col-md-12">
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.2 - Perfil de Curso '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.3 - Perfil de Egresso '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
              </div>
              <div class="col-md-12">
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.4 - Forma de Acesso ao Curso '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.5 - Representação Gráfica de um perfil de formação '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
              </div>
              <div class="col-md-12">
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.6 - Sistema de Avaliação '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.7 - Sistema de Avaliação do Projeto de Curso '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
                  <div class="col-md-6">
                      <?php echo Form::label('nome_curso', '1.3 - Trabalho de Conclusão de Curso '); ?>                 
                     <?php echo Form::input('text', 'nome_curso', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>

                    
                    <?php echo Form::label('nome_curso', '1.3 - Estágio Curricular'); ?>                 
                    <?php echo Form::input('text', 'nome_curso', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>


                  </div>
                   <div class="col-md-12">
                    <?php echo Form::label('nome_curso', '1.3 - Política de Atendimento a Pessoas com Deficiencias '); ?>                 
                    <?php echo e(Form::textarea('notes', null, ['class' => 'form-control','size' => '30x3'])); ?>

                  </div>
               </div>
               <div class="col-md-12" style="margin-top:50px">   
                            <?php echo Form::submit('Salvar', ['class' => 'btn btn-primary']); ?>

                            <?php echo Form::reset('Limpar formulário', ['class' => 'btn btn-default']); ?>

                        </div>
            <?php echo Form::close(); ?> 
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>