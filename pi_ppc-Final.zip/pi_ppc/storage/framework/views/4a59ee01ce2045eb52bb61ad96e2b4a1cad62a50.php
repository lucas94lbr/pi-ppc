<?php $__env->startSection('template_title'); ?>
  Criar novo usuário
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_fastload_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">

            Criar Novo Coordenador

            <a href="/coordenadores" class="btn btn-info btn-xs pull-right">
              <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
              Voltar para <span class="hidden-xs"></span><span class="hidden-xs"> Coordenadores</span>
            </a>

          </div>
          <div class="panel-body">
            <?php echo Form::open(array('route' => 'coordenadores.store', 'files' => true)); ?>

              <legend>1 - Dados do Coordenador</legend>
               <div class="col-md-12">
                  <?php echo Form::label('nome_curso', '3.1 - Nome de Coordenador'); ?>

                  <?php echo Form::input('text', 'nome', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Coordenador']); ?>

                </div>
                <br>
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '3.2 - CPF'); ?> 
                  <?php echo Form::input('int', 'cpf', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite o CPF do Coordenador.']); ?> 
                </div>
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '3.3 - Titulação'); ?> 
                  <?php echo Form::select('titulacao', ['Graduado' => 'Graduado', 'Mestre' => 'Mestre' , 'Doutor' => 'Doutor'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione a Titulação']); ?>

                </div>
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '3.4 - Tempo de Dedicação'); ?> 
                  <?php echo Form::input('int', 'dedicacao', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite em anos.']); ?> 
                </div>
               <div class="col-md-12" style="margin-top:50px">   
                            <?php echo Form::submit('Salvar', ['class' => 'btn btn-primary']); ?>

                            <?php echo Form::reset('Limpar formulário', ['class' => 'btn btn-default']); ?>

                        </div>
            <?php echo Form::close(); ?> 
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>