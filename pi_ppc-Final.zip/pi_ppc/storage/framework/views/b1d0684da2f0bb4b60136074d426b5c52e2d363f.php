<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
			  <!-- Default panel contents -->
				<div class="panel-heading">Professores Cadastrados 
			  		<a href="/professores/create" class="btn btn-sm btn-success pull-right">Novo Professor</a>
			  	</div>
			  	<div class="panel-body">
			    	<table class="table">
			          	<thead class="thead-dark">
			            	<tr>
			              		<th scope="col">#</th>
					              <th scope="col">Titulação</th>
					              <th scope="col">Nome</th>
					              <th scope="col">Área de Formação</th>
					              <th scope="col">Ações</th>
					            </tr>
			          	</thead>
	          			<tbody>
			            	<?php $__currentLoopData = $professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			            		<tr>
			              			<th scope="row"><?php echo e($professor->id); ?></th>
						            <td><a href="/cursos/<?php echo e($professor->id); ?>"><?php echo e($professor->nome); ?></a></td>
						            <td><?php echo e($professor->area_formacao); ?></td>						            <td>
			              				<div class="btn-group" role="group" aria-label="Basic example">
			                  				<a href="<?php echo e(URL::to('professor/' . $professor->id . '/edit')); ?>">
			                   					<button type="button" class="btn btn-xs btn-warning">Editar</button>
			                  				</a>
					                  		<form action="<?php echo e(url('professores', [$professor->id])); ?>" method="POST">
					     						<input type="hidden" name="_method" value="DELETE">
											   	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
											   	<input type="submit" class="btn btn-xs btn-danger" value="Apagar"/>
					   				  		</form>
			              				</div>
			 						</td>
			            		</tr>
			            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	          			</tbody>
        			</table>
			  	</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>