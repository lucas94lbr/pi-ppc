<?php $__env->startSection('template_title'); ?>
Criar Novo Curso
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_fastload_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">

            Criar Novo Curso

            <a href="/cursos" class="btn btn-info btn-xs pull-right">
              <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
              Voltar para <span class="hidden-xs"></span><span class="hidden-xs"> Cursos</span>
            </a>

          </div>
          <div class="panel-body">
            <?php echo Form::open(array('route' => 'cursos.store', 'files' => true)); ?>

              <legend>1 - Dados do Curso</legend>
              <div class="col-md-12">
                <div class="col-md-6">
                  <?php echo Form::label('tipo_curso', '1.1 - Tipo de Curso'); ?> 
                  <?php echo Form::select('tipo_curso', ['Tecnológico' => 'Tecnológico', 'Bacharelado' => 'Bacharelado' , 'Licenciatura' => 'Licenciatura'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione o Tipo de Curso']); ?>

                </div>
                <div class="col-md-6">
                  <?php echo Form::label('modalidade', '1.2 - Modalidade'); ?> 
                  <?php echo Form::select('modalidade', ['EAD' => 'EAD', 'Presencial' => 'Presencial' , 'Semi-Presencial' => 'Semi-Presencial'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione a Modalidade']); ?>

                </div>
                <div class="col-md-12">
                  <?php echo Form::label('nome_curso', '1.3 - Curso '); ?>

                  <?php echo Form::input('text', 'nome_curso', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>

                </div>
                <br>
                <div class="col-md-6">
                  <?php echo Form::label('habilitacao', '1.4 - Habilitação'); ?> 
                  <?php echo Form::input('text', 'habilitacao', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Habilitação']); ?> 
                </div>
                <div class="col-md-6">
                  <?php echo Form::label('local', '1.5 - Local da Oferta'); ?> 
                  <?php echo Form::input('text', 'local', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div>
                <div class="col-md-6">
                  <?php echo Form::label('turno', '1.6 -   Turno'); ?> 
                  <?php echo Form::select('turno', ['Noturno' => 'Noturno', 'Vespertino' => 'Vespertino' , 'Matutino' => 'Matutino'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione o Turno']); ?>

                </div>
                <div class="col-md-6">
                  <?php echo Form::label('vagas', '1.7 - Vagas'); ?> 
                  <?php echo Form::input('int', 'vagas', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div> 
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '1.8 - Carga Horária'); ?> 
                  <?php echo Form::input('int', 'carga_horaria', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div>
              </div>
              <br>
              <br>
              <br>
              <legend>2 - Estrutura Curricular</legend>
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '2.1 - Regime Letivo'); ?> 
                  <?php echo Form::input('int', 'regime', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div> 
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '2.2 - Períodos'); ?> 
                  <?php echo Form::input('int', 'periodos', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div>
              <legend>3 - Dados do Coordenador</legend>
               <div class="col-md-12">
                  <?php echo Form::label('nome_curso', '3.1 - Nome de Coordenador'); ?>

                  
                  <select class="form-control" name="coordenador_id">
                    <option value="" disabled selected hidden>Coordenador</option>
                      <?php $__currentLoopData = $coordenadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordenador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($coordenador->id); ?>"><?php echo e($coordenador->nome); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <br>
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '3.2 - CPF'); ?> 
                  <?php echo Form::input('int', 'carga_horaria', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div>
                <div class="col-md-6">
                  <?php echo Form::label('modalidade', '1.3 - Titulação'); ?> 
                  <?php echo Form::select('modalidade', ['Graduado' => 'Graduado', 'Mestre' => 'Mestre' , 'Doutor' => 'Doutor'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione a Titulação']); ?>

                </div>
                <div class="col-md-6">
                  <?php echo Form::label('carga_horaria', '3.4 - Tempo de Dedicação'); ?> 
                  <?php echo Form::input('int', 'carga_horaria', null, ['class' => 'form-control' ,'autofocus', 'placeholder' => 'Digite a carga horária em horas.']); ?> 
                </div>
               <div class="col-md-12" style="margin-top:50px">   
                            <?php echo Form::submit('Salvar', ['class' => 'btn btn-primary']); ?>

                            <?php echo Form::reset('Limpar formulário', ['class' => 'btn btn-default']); ?>

                        </div>
            <?php echo Form::close(); ?> 
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>