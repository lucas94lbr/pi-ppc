<?php $__env->startSection('template_title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_fastload_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">

           Novo Professor

            <a href="/professores" class="btn btn-info btn-xs pull-right">
              <i class="fa fa-fw fa-mail-reply" aria-hidden="true"></i>
              Voltar para <span class="hidden-xs"></span><span class="hidden-xs"> Professores</span>
            </a>

          </div>
          <div class="panel-body">
          	<ul class="nav nav-tabs">
  <li class="active"><a href="#">Dados Pessoais</a></li>
  <li><a href="#">Atuação IES</a></li>
  <li><a href="#">Atuação Profissional</a></li>
  <li><a href="#">Publicações</a></li>
</ul>
            <?php echo Form::open(array('route' => 'professores.store', 'files' => true)); ?>

              <legend>1 - Professor</legend>
              <div class="col-md-12">
                
                <div class="col-md-6">
                  <?php echo Form::label('modalidade', '1.1 - Nome Completo'); ?> 
                  <?php echo Form::input('text', 'nome', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>

                  <?php echo Form::label('modalidade', '1.3 - Titulação'); ?> 
                  <?php echo Form::select('titulacao', ['Graduado' => 'Graduado', 'Mestre' => 'Mestre' , 'Doutor' => 'Doutor'], null, ['class' => 'form-control' ,'autofocus','placeholder' => 'Selecione a Titulação']); ?>

                  <?php echo Form::label('nome_curso', '1.5 - Currículo Lattes'); ?>  
                  <?php echo Form::input('text', 'lattes', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>

                </div>
                
                  <div class="col-md-6">
                    <?php echo Form::label('nome_curso', '1.2 - Trabalho de Conclusão de Curso '); ?>                 
                    <?php echo Form::input('text', 'tcc', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>

                    
                    <?php echo Form::label('nome_curso', '1.4 - Área de Formação'); ?>                 
                    <?php echo Form::input('text', 'area_formacao', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome da Área de Formação']); ?>

                    
                    <?php echo Form::label('nome_curso', '1.6 - Data de Atualização'); ?>                 
                    <?php echo Form::input('text', 'data', null, ['class' => 'form-control', 'required' =>'required','autofocus', 'placeholder' =>'Digite o nome do Curso']); ?>



               </div>
 
               <div class="col-md-12" style="margin-top:50px">   
                            <?php echo Form::submit('Salvar', ['class' => 'btn btn-primary']); ?>

                            <?php echo Form::reset('Limpar formulário', ['class' => 'btn btn-default']); ?>

                        </div>
            <?php echo Form::close(); ?> 
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>