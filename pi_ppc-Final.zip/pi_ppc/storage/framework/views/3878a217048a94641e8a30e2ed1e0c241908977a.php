<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="panel panel-default">
        <!-- Default panel contents -->
        <div class="panel-heading"> Coordenadores Cadastrados 
            <a href="/coordenadores/create" class="btn btn-sm btn-success pull-right">Novo Coordenador</a>
          </div>
          <div class="panel-body">
            <table class="table">
                  <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Coordenador</th>
                        <th scope="col">Titulação</th>
                        <th scope="col">Ações</th>
                      </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $coordenadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($coo->id); ?></th>
                        <td><?php echo e($coo->nome); ?></td>
                        <td><?php echo e($coo->titulacao); ?></td>                         
                        <td>
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(URL::to('coordenadores/' . $coo->id . '/edit')); ?>">
                                  <button type="button" class="btn btn-xs btn-warning">Editar</button>
                                </a>
                                <form action="<?php echo e(url('coordenadores', [$coo->id])); ?>" method="POST">
                          <input type="hidden" name="_method" value="DELETE">
                          <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                          <input type="submit" class="btn btn-xs btn-danger" value="Apagar"/>
                          </form>
                            </div>
                  </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>